export interface GenericPrismaDelegate {
    create: any,
    update: any,
    delete: any,
    findMany: any,
    findFirst: any
}